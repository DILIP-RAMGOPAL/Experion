
import java.io.*;
public class geektrust{

    public static void main(String args[]) throws FileNotFoundException
    {	
//To take input from compiler as text file
    	BufferedReader reader = new BufferedReader(new FileReader(args[0]));
 	String str="";
	try
	{
		str=reader.readLine();
	}
	catch(IOException e) 
	{
  		e.printStackTrace();
	}
//declaring i j and t	
	int j;
	int i;
	int t=0;
//Speed of each vehicle is declared where 1st three integers are for calcualing speed in orbit 1 and last three for calculating speed in orbit 2 
	double[] speed = {10,12,20,10,12,20};
	double[] time = {0,0,0,0,0,0};
//input string is splited to take weather and speed of orbit1 and orbit2 
	String[] arrOfStr = str.split(" "); 
//To find smallest time 
	double small;
//Speed of orbit1 is stored in gs1 speed of orbit2 is stored in gs2
	double gs1=Integer.parseInt(arrOfStr[1]);
	double gs2=Integer.parseInt(arrOfStr[2]);
//to initialize speed given orbit speed if speed of vehicle is more than orbit speed
	for(i=0;i<6;i++)
	{
		if (i<=2 && speed[i]>gs1)
			speed[i]=gs1;
		else if (i>2 && speed[i]>gs2)
			speed[i]=gs2;
	}  
//Calculating time taken by vehicle if in sunny weather      
	if (arrOfStr[0].equals("SUNNY"))
	{
		time[0]=18*((double)1/speed[0])+((double)36/60);
		time[1]=18*((double)1/speed[1])+((double)18/60);
		time[2]=18*((double)1/speed[2])+((double)54/60);
		time[3]=20*((double)1/speed[3])+((double)18/60);
		time[4]=20*((double)1/speed[4])+((double)9/60);
		time[5]=20*((double)1/speed[5])+((double)27/60);
		small = time[0];
//Finding smallest time and initializing t to show position of smallest time
		for(j=0;j<6;j++)
			if (time[j]<small)
			{
				small=time[j];
				t=j;
			}
//print output based on smallest time	
		if (t==0)
        		System.out.println("BIKE ORBIT1");
		else if (t==1)
        		System.out.println("TUKTUK ORBIT1");
        	else if (t==2)
        		System.out.println("CAR ORBIT1");
        	else if (t==3)
        		System.out.println("BIKE ORBIT2");
        	else if (t==4)
        		System.out.println("TUKTUK ORBIT2");
        	else if (t==5)
        		System.out.println("CAR ORBIT2");
	}
//Calculating time taken by vehicle if in rainy weather
	else if (arrOfStr[0].equals("RAINY"))
	{
		time[0]=((18*((double)1/speed[0]))+((double)42/60));
		time[1]=((18*((double)1/speed[1]))+((double)24/60));
		time[2]=((18*((double)1/speed[2]))+((double)72/60));
		time[3]=((20*((double)1/speed[3]))+((double)24/60));
		time[4]=((20*((double)1/speed[4]))+((double)12/60));
		time[5]=((20*((double)1/speed[5]))+((double)36/60));
		small = time[0];
//Finding smallest time and initializing t to show position of smallest time
		for(j=0;j<6;j++)
			if (time[j]<small)
			{
				small=time[j];
				t=j;
			}
//print output based on smallest time			
		if (t==0)
        		System.out.println("BIKE ORBIT1");
		else if (t==1)
        		System.out.println("TUKTUK ORBIT1");
        	else if (t==2)
        		System.out.println("CAR ORBIT1");
        	else if (t==3)
        		System.out.println("BIKE ORBIT2");
        	else if (t==4)
        		System.out.println("TUKTUK ORBIT2");
        	else if (t==5)
        		System.out.println("CAR ORBIT2");
	}
//Calculating time taken by vehicle if in windy weather
	else if (arrOfStr[0].equals("WINDY"))
	{
		time[0]=18*((double)1/speed[0])+((double)40/60);
		time[1]=18*((double)1/speed[1])+((double)20/60);
		time[2]=18*((double)1/speed[2])+((double)60/60);
		time[3]=20*((double)1/speed[3])+((double)20/60);
		time[4]=20*((double)1/speed[4])+((double)10/60);
		time[5]=20*((double)1/speed[5])+((double)30/60);
		small = time[0];
//Finding smallest time and initializing t to show position of smallest time
		for(j=0;j<6;j++)
			if (time[j]<small)
			{
				small=time[j];
				t=j;
			}	
//print output based on smallest time
		if (t==0)
        		System.out.println("BIKE ORBIT1");
		else if (t==1)
        		System.out.println("TUKTUK ORBIT1");
        	else if (t==2)
        		System.out.println("CAR ORBIT1");
        	else if (t==3)
        		System.out.println("BIKE ORBIT2");
        	else if (t==4)
        		System.out.println("TUKTUK ORBIT2");
        	else if (t==5)
        		System.out.println("CAR ORBIT2");
	}
  }
}
