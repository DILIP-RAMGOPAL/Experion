Tame of Thrones

I have writter my code in python 3.8.2 in jupyter notebook.
In main() : The input is taken from the command lind as text file. Each line of the input file 		    is passed to allie_or_not() as parameters 
	    
In Allie_or_not() : Each line is splited in to two kindom_name and coded_message. The 			     coded_message is passed to decode() as parameters to decode the message. 			     Every decoded message is checked to see if it contains all the letters of 			     its emblem. 

In decode() : Each message is decoded using length of emblem. Calls decode_letter() and passed 		      coded letter as parameters

In decode_letter() : Each coded letter is accepted as parameters and decoded letter is returned
