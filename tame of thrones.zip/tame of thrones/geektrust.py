#!/usr/bin/env python
# coding: utf-8

# In[2]:


king={"space":"gorilla", "land":"panda", "water":"octopus","ice":"mammoth", "air":"owl", "fire":"dragon"}


# In[80]:


#Take each letter and decode it

def decode_letter(coded_letter,length_Kingdom_name):
    
    decoded_letter=chr((ord(coded_letter) - ord('A') - 6 - length_Kingdom_name) % 26 + ord('A')).lower()
    return decoded_letter

#Take each word and decode it

def decode(line):
    
    decoded_message = ''
    Kingdom_name = ''
    Kingdom_name = line.split()
    
    coded_message = ''.join(Kingdom_name[1:]) 
    length_Kingdom_name = len(king[Kingdom_name[0]])
    
    for i in range (0 , len(coded_message)):
        decoded_message += decode_letter (coded_message[i] , length_Kingdom_name)
    
    return decoded_message,Kingdom_name

#Checking if allie or not    

def allie_or_not(line):
    
    decoded_message,Kingdom_name = decode(line)
    allie = 0
    emblem = king[Kingdom_name[0]]
    
    for i in range (0,len(decoded_message)):
        if decoded_message[i] in emblem:
            emblem = emblem.replace(decoded_message[i], '', 1)
    
    if emblem == '': 
        allie = 1
        return allie
    
    else:
        return allie


# In[79]:


# calling functions to check if allie of space or not

import sys
def main():

    Allies = ''
    counter = 0
    NumberOfLines = 0
    
    inFile = sys.argv[1]
    with open(inFile,'r') as i:
        line = i.read()
    line = line.split("\n")
    
    for i in line: 
        if i: 
            NumberOfLines += 1
    
    for i in range ( 0 , NumberOfLines):
        
        line[i] = line[i].lower()
        line_split = line[i].split()
    
        if line_split[0] in king.keys():
            allie = allie_or_not(line[i])

            if allie==1 and line_split[0] not in Allies:
                Allies = Allies + ' ' + line_split[0]
                counter = counter+1

        else:
            print("Kingdom do not exist")

    print("\n")
    Allies = Allies.upper()
    
    if counter >= 3:
         print("SPACE" + Allies)
    
    else:
            print("NONE")

if __name__=="__main__":    
    main()


# In[ ]:




