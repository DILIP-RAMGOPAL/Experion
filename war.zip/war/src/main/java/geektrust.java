import java.io.*;
public class geektrust{

    public static void main(String args[]) throws FileNotFoundException
    {	
//To take input from compiler as text file
    	BufferedReader reader = new BufferedReader(new FileReader(args[0]));
 	String str="";
	try
	{
		str=reader.readLine();
	}
	catch(IOException e) 
	{
  		e.printStackTrace();
	}
//initializing array for putting input values
	String[] nc=new String[20];
	int[] in=new int[20];
	int[] ine=new int[20];
	StringBuffer alpha = new StringBuffer(),num = new StringBuffer(), special = new StringBuffer(); 
//Spliting input data to get value of each battalion
	String[] yarr = str.split(" ");
	String[] arr = new String[20];
	int n=yarr.length-1;
//Deleting the first element of which is "FALICORNIA_ATTACK"  
	System.arraycopy(yarr,1,arr,0,n);
//Extracting number of each battalion from string input
	for (int i=0;i<n;i++)
	{
		
       	 for (int j=0; j<arr[i].length(); j++) 
       	 { 
       	     if (Character.isDigit(arr[i].charAt(j)))
       	     { 
       	         num.append(arr[i].charAt(j)); 
       	 
        	    }
        	    else if(Character.isAlphabetic(arr[i].charAt(j))) 
        	    {
        	        alpha.append(arr[i].charAt(j));
		    }
		 }
		 
		 nc[i]=alpha.toString();
		 in[i]=Integer.parseInt(num.toString());
//Find half of each battalion If odd number, rounding up
		 if(in[i]%2!=0)
			ine[i]=(in[i]*1/2)+1;
		else
			ine[i]=in[i]*1/2;
		
		 num=new StringBuffer("");
		 alpha=new StringBuffer("");
	
	}

//Finding if Lengaburu wins or not
    	int i;
    	String s="WINS";
//if number of Sling guns is greater than 5 and number of attack tanks is less than 10 add subtract the extra amount from sling gun and add 2* extra sling guns to attack tanks  
    		if (ine[3]>5 && ine[2]<10)
    		{	
    			ine[2]=ine[3-1]+(2*(ine[3]-5));
    			ine[3]=ine[3]-(ine[3]-5);
//After adding in above step is number of Attack tanks becomes more than 10 change it to 10
    			if(ine[2]>10)
    				ine[2]=10;
    		}
//If number of sling guns is greater than 5 and attack tanks in greater than 10 Lengaburu losses
    		if(ine[3]>=5 && ine[2]>=10)
    		{
    	
    			s="LOSES";
    			ine[3]=5;
    		}
//If number of attack tanks in greater than 10 and number of elephants is less than 50 
    		if (ine[2]>10 && ine[1]<50)
    		{
    			ine[2-1]=ine[2-1]+(2*(ine[2]-10));
    				ine[2]=ine[2]-(ine[2]-10);
//After adding in above step is number of elephants becomes more than 50 change it to 50
    			if(ine[1]>50)
    				ine[1]=50;
    		}
//If number of attack tanks in greater than 10 , number of elephants is greater than 50 and number of Sling guns in less than 5
    		if(ine[2]>10 && ine[1]>50 && ine[3]<5)
    		{	
    			if(ine[2]%2!=0)
				ine[2+1]=ine[2+1]+((ine[2]-9)*1/2);
			else
				ine[2+1]=ine[2+1]+((ine[2]-10)*1/2);
			ine[2]=ine[2]-(ine[2]-10);
//After adding if number of elephants becomes more than 50 changes are made to number of sling guns			
			if(ine[1]>50)
			{
				ine[3]=ine[3]+((ine[1]-50)*1/4);
				ine[1]=ine[1]-(ine[1]-50);
			}
		}
//If number of attack tanks in greater than 10 , number of elephants is greater than 50 and number of Sling guns in greater than 5 Lengaburu losses
		else if(ine[2]>=10 && ine[2-1]>=50 && ine[2+1]>=5)
		{
			s="LOSES";
    			ine[2]=10;
    		}
//If number of elephants is greater than 50 and number of horses is less than 100
    		if (ine[1]>50 && ine[1-1]<100)
    		{
    			ine[1-1]=ine[1-1]+(2*(ine[1]-50));
    				ine[1]=ine[1]-(ine[1]-50);
    			if(ine[0]>100)
    				ine[0]=100;
    		}
//If number of elephants is greater than 50 and number of horses is greater than 100 and number of Attack tanks less than 10
    		if(ine[1]>50 && ine[1-1]<100 && ine[1+1]<10)
    		{
    			if(ine[1]%2!=0)
				ine[1+1]=ine[1+1]+((ine[1]-49)*1/2);
			else
				ine[1+1]=ine[1+1]+((ine[1]-50)*1/2);
			ine[1]=ine[1]-(ine[1]-50);
			if(ine[0]>100)
			{
				ine[2]=ine[2]+((ine[0]-100)*1/4);
				ine[0]=ine[0]-(ine[0]-50);
			}
		}
//If number of elephants is greater than 50, number of horses is greater than 100 and number of Attack tanks greater than 10 Lengaburu losses
		else if(ine[1]>=50 && ine[1-1]>=10 && ine[1+1]>=10)
		{
			s="LOSES";
    			ine[1]=50;
    		}
//If number of horses is greater than 100 and numbe of elephants in less than 50
    		if (ine[0]>100 && ine[0+1]<50)
    		{
    			
    			if(ine[0]%2!=0)
				ine[0+1]=ine[0+1]+((ine[0]-99)*1/2);
			else
				ine[0+1]=ine[0+1]+((ine[0]-100)*1/2);
    			ine[0]=ine[0]-(ine[0]-100);
    		}
//If number of horses is greater than 100 and numbe of elephants in greater than 50 Lengaburu losses
    		else if(ine[0]>=100 && ine[1]>=50)
    		{
    			s="LOSES";
    			ine[0]=100;
    		}
//printing wins or losses
    		System.out.print(s+" ");
//printing amount of battalions required by Lengaburu
    	for ( i=0;i<n;i++)
    		System.out.print(ine[i]+nc[i]+" ");
    }
}
